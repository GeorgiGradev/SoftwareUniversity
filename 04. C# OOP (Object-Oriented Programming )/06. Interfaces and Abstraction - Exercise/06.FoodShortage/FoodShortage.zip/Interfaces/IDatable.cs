﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    interface IDatable
    {
        public string BirthDate { get; }
    }
}
