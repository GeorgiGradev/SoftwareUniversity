﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    public interface IHumanable   
    {
        public string Name { get; }
        public int Age { get; }


    }
}
