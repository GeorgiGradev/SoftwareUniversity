﻿using System;

namespace FoodShortage
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine.Run();
        }
    }
}
