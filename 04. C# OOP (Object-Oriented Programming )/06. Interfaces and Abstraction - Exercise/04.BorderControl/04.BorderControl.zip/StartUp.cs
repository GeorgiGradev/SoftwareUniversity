﻿using System;

namespace _04.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine.Run();
        }
    }
}
