﻿using System;

namespace BirthdayCelebrations
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine.Run();
        }
    }
}
