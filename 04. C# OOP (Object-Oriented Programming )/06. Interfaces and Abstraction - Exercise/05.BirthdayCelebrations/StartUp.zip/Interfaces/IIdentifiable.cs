﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations.Interfaces
{
    public interface IIdentifiable
    {
        public string ID { get;  }
    }
}
