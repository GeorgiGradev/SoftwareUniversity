﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace FootballTeamGenerator
{
    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
