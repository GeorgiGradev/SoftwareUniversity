﻿using System;

namespace BankSafe
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
        }
    }
}
