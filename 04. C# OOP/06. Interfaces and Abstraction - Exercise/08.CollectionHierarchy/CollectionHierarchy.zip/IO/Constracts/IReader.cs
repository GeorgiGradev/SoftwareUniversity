﻿namespace CollectionHierarchy.IO.Constracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
