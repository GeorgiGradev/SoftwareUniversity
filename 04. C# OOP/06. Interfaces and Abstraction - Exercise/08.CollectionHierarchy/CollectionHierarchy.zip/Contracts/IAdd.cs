﻿namespace CollectionHierarchy.Contracts
{
    public interface IAdd
    {
        int Add(string element);
    }
}
