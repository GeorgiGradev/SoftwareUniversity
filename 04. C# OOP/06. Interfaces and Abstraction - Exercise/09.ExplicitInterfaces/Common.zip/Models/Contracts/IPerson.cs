﻿namespace Explicit_Interfaces.Models.Contracts
{
    public interface IPerson
    {

        public string Name { get;}
        public int Age { get;}
        string GetName();
    }
}
