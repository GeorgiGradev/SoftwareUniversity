﻿using System;

namespace _03.Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Enigne.Run();
        }
    }
}
