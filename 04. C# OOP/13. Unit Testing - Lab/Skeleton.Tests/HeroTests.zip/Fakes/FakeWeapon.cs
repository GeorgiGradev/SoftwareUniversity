﻿namespace Skeleton.Tests.Fakes
{ 
    public class FakeWeapon : IWeapon
    {
        public void Attack(ITarget target)
        {
           
        }
    }
}
