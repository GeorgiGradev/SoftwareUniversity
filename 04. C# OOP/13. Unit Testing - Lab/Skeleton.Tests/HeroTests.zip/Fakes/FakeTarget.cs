﻿namespace Skeleton.Tests.Fakes
{
    public class FakeTarget : ITarget
    {
        public const int DefaultExperience = 100;
        public bool IsDead() => true;
        public int GiveExperience() => DefaultExperience;

        public void TakeAttack(int damage)
        {
        }
    }
}
