﻿namespace Skeleton.Tests.Contracts
{
    public interface ITarget
    {
        bool IsDead();
        int GiveExperience();
        void TakeAttack(int damage);
    }
}
