namespace ParkingSystem.Tests
{ 
    public class SoftParkTest
    {
        
    }
}