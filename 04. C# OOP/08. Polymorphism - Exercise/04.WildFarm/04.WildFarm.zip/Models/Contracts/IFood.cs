﻿
namespace _04.WildFarm.Models.Contracts
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}
