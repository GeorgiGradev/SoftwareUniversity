﻿using System;
using _01.Vehicles.Engines;

namespace _01.Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine.Run();
        }
    }
}
